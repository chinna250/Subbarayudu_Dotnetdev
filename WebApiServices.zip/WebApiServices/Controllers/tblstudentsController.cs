﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Description;
using WebApiServices.Models;

namespace WebApiServices.Controllers
{
    public class tblstudentsController : ApiController
    {
        private studentEntities db = new studentEntities();

        // GET: api/tblstudents
        public IQueryable<tblstudent> Gettblstudents()
        {
            return db.tblstudents;
        }

        // GET: api/tblstudents/5
        [ResponseType(typeof(tblstudent))]
        public IHttpActionResult Gettblstudent(int id)
        {
            tblstudent tblstudent = db.tblstudents.Find(id);
            if (tblstudent == null)
            {
                return NotFound();
            }

            return Ok(tblstudent);
        }

        // PUT: api/tblstudents/5
        [ResponseType(typeof(void))]
        public IHttpActionResult Puttblstudent(int id, tblstudent tblstudent)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != tblstudent.ID)
            {
                return BadRequest();
            }

            db.Entry(tblstudent).State = EntityState.Modified;

            try
            {
                db.SaveChanges();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!tblstudentExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return StatusCode(HttpStatusCode.NoContent);
        }

        // POST: api/tblstudents
        [ResponseType(typeof(tblstudent))]
        public IHttpActionResult Posttblstudent(tblstudent tblstudent)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            db.tblstudents.Add(tblstudent);
            db.SaveChanges();

            return CreatedAtRoute("DefaultApi", new { id = tblstudent.ID }, tblstudent);
        }

        // DELETE: api/tblstudents/5
        [ResponseType(typeof(tblstudent))]
        public IHttpActionResult Deletetblstudent(int id)
        {
            tblstudent tblstudent = db.tblstudents.Find(id);
            if (tblstudent == null)
            {
                return NotFound();
            }

            db.tblstudents.Remove(tblstudent);
            db.SaveChanges();

            return Ok(tblstudent);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

        private bool tblstudentExists(int id)
        {
            return db.tblstudents.Count(e => e.ID == id) > 0;
        }
    }
}